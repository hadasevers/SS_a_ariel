
void gimatric(char *word, char *text);
void atbash(char *word, char *text);
void anagram(char *word, char *text);